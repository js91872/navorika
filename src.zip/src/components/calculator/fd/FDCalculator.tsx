"use client";

import { useMemo, useState } from "react";

import CalculatorShell from "../CalculatorShell";
import CalculatorHeader from "../CalculatorHeader";
import NumberInput from "../NumberInput";
import PercentageInput from "../PercentageInput";
import TenureInput from "../TenureInput";
import Slider from "../Slider";
import ResultGrid from "../ResultGrid";
import ResultCard from "../ResultCard";
import PieChart from "../PieChart";
import Summary from "../Summary";

import { calculateFD } from "@/lib/calculations/fd";
import { formatCurrency } from "@/lib/format/currency";

export default function FDCalculator() {
  const [depositAmount, setDepositAmount] = useState(100000);

  const [interestRate, setInterestRate] = useState(7.25);

  const [tenure, setTenure] = useState(5);

  const [frequency, setFrequency] = useState(4);

  const result = useMemo(() => {
    return calculateFD(
      depositAmount,
      interestRate,
      tenure,
      frequency
    );
  }, [
    depositAmount,
    interestRate,
    tenure,
    frequency,
  ]);

  return (
    <CalculatorShell>
      <CalculatorHeader
        title="FD Calculator"
        description="Estimate the maturity amount and interest earned on your Fixed Deposit."
      />

      <div className="grid gap-12 lg:grid-cols-[1fr_420px]">

        {/* LEFT PANEL */}

        <div className="space-y-10">

          <div className="space-y-3">

            <NumberInput
              label="Deposit Amount"
              value={depositAmount}
              onChange={setDepositAmount}
              prefix="₹"
              min={1000}
            />

            <Slider
              value={depositAmount}
              min={1000}
              max={10000000}
              step={1000}
              onChange={setDepositAmount}
            />

          </div>

          <div className="space-y-3">

            <PercentageInput
              label="Interest Rate"
              value={interestRate}
              onChange={setInterestRate}
            />

            <Slider
              value={interestRate}
              min={1}
              max={12}
              step={0.05}
              onChange={setInterestRate}
            />

          </div>

          <div className="space-y-3">

            <TenureInput
              value={tenure}
              onChange={setTenure}
            />

            <Slider
              value={tenure}
              min={1}
              max={20}
              step={1}
              onChange={setTenure}
            />

          </div>

          <div className="space-y-3">

            <label className="block text-sm font-medium">
              Compounding Frequency
            </label>

            <select
              value={frequency}
              onChange={(e) =>
                setFrequency(Number(e.target.value))
              }
              className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 outline-none focus:border-blue-600"
            >
              <option value={1}>Yearly</option>
              <option value={2}>Half-Yearly</option>
              <option value={4}>Quarterly</option>
              <option value={12}>Monthly</option>
            </select>

          </div>

        </div>

        {/* RIGHT PANEL */}

        <div className="space-y-6">

          <ResultGrid>

            <ResultCard
              label="Deposit Amount"
              value={formatCurrency(result.investedAmount)}
            />

            <ResultCard
              label="Interest Earned"
              value={formatCurrency(result.interestEarned)}
            />

            <ResultCard
              label="Maturity Amount"
              value={formatCurrency(result.maturityAmount)}
              highlight
            />

          </ResultGrid>

          <PieChart
            principal={result.investedAmount}
            interest={result.interestEarned}
          />

          <Summary
            principal={result.investedAmount}
            interest={result.interestEarned}
            total={result.maturityAmount}
          />

        </div>

      </div>

    </CalculatorShell>
  );
}