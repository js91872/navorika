'use client';

import { useState } from 'react';
import { ArrowLeft, Code, ShieldCheck, RefreshCw, Copy, Check } from 'lucide-react';
import { tools } from '@/data/registry';

export default function Base64EncoderTool() {
  const meta = tools.find(t => t.slug === 'base64-encoder');
  // Default meta if not found
  const toolMeta = meta || {
    heroTitle: "Base64 Encoder",
    heroDescription: "Process your documents efficiently with this tool.",
    formulaExplanation: "This tool processes your data locally in your browser for maximum privacy and speed.",
    faq: [
      { question: "How does this tool work?", answer: "All processing happens locally in your browser. No data is ever uploaded to any server." },
      { question: "Is my data safe?", answer: "Yes! Your files and data never leave your computer." },
      { question: "Do I need to install anything?", answer: "No installation needed. Everything runs directly in your web browser." }
    ]
  };

  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');
  const [copied, setCopied] = useState(false);

  const processText = () => {
    try {
      if (mode === 'encode') {
        setOutput(btoa(input));
      } else {
        setOutput(atob(input));
      }
    } catch (err) {
      setOutput('Invalid string format for translation processing.');
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!meta) return null;

  return (
    <main className="max-w-4xl mx-auto px-6 py-12 lg:px-8">
      <a href="/categories/developer-tools" className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-emerald-600 transition mb-8">
        <ArrowLeft className="h-4 w-4" /> Back to Developer Tools
      </a>
      
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-wider mb-4 border border-emerald-500/20">
          <ShieldCheck className="h-4 w-4" /> Local String Processing
        </div>
        <h1 className="text-4xl font-black text-slate-900 dark:text-white mb-4">{toolMeta.heroTitle}</h1>
        <p className="text-lg text-slate-600 dark:text-slate-400">{toolMeta.heroDescription}</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden mb-16 p-8 space-y-6">
        <div className="flex gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <button 
            onClick={() => { setMode('encode'); setInput(''); setOutput(''); }}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${mode === 'encode' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
          >
            Text ➔ Base64
          </button>
          <button 
            onClick={() => { setMode('decode'); setInput(''); setOutput(''); }}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${mode === 'decode' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
          >
            Base64 ➔ Text
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Input String</label>
            <textarea 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={mode === 'encode' ? 'Type clean text here...' : 'Paste Base64 stream here...'}
              className="w-full h-48 p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-mono outline-none text-slate-900 dark:text-white resize-none"
            />
          </div>
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Output Result</label>
              {output && (
                <button onClick={copyToClipboard} className="text-xs text-slate-400 hover:text-emerald-500 flex items-center gap-1">
                  {copied ? <Check className="h-3 w-3 text-emerald-500"/> : <Copy className="h-3 w-3"/>}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              )}
            </div>
            <textarea 
              readOnly
              value={output}
              className="w-full h-48 p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-mono outline-none text-slate-700 dark:text-slate-400 resize-none"
            />
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
          <button onClick={processText} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-bold transition shadow-md">
            <RefreshCw className="h-4 w-4" />
            {mode === 'encode' ? 'Encode Text' : 'Decode Base64'}
          </button>
        </div>
      </div>
    </main>
  );
}
