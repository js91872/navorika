'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Utensils, Target, Flame } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { ResultCard } from '@/components/ui/ResultCard';
import { Container } from '@/components/ui/Container';
import { calculateTDEE } from '@/lib/calculations/health';

const ACTIVITY_OPTIONS = [
  { value: 'sedentary', label: 'Sedentary' },
  { value: 'light', label: 'Light' },
  { value: 'moderate', label: 'Moderate' },
  { value: 'active', label: 'Active' },
  { value: 'very-active', label: 'Very Active' },
];

const GOAL_OPTIONS = [
  { value: 'maintain', label: 'Maintain Weight' },
  { value: 'lose', label: 'Lose Weight' },
  { value: 'gain', label: 'Gain Weight' },
];

export default function CalorieCalculator() {
  const [age, setAge] = useState(30);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [weight, setWeight] = useState(70);
  const [height, setHeight] = useState(175);
  const [activityLevel, setActivityLevel] = useState<'sedentary' | 'light' | 'moderate' | 'active' | 'very-active'>('moderate');
  const [goal, setGoal] = useState<'maintain' | 'lose' | 'gain'>('maintain');
  const [result, setResult] = useState<any>(null);

  const handleCalculate = () => {
    const tdeeResult = calculateTDEE({ age, gender, weight, height, activityLevel });
    const calories = goal === 'maintain' ? tdeeResult.tdee : goal === 'lose' ? tdeeResult.tdee - 500 : tdeeResult.tdee + 300;
    setResult({ ...tdeeResult, goal, calories });
  };

  return (
    <Container maxWidth="xl" className="py-8">
      <Link href="/categories/health-calculators" className="inline-flex items-center gap-2 text-sm text-indigo-600 hover:underline mb-6">
        <ArrowLeft className="h-4 w-4" /> Back
      </Link>
      <h1 className="text-3xl font-black mb-2">Calorie Calculator</h1>
      <p className="text-slate-600 dark:text-slate-400 mb-8">Calculate your daily calorie needs</p>

      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Input label="Age" type="number" value={age} onChange={(e) => setAge(Number(e.target.value))} />
              <div>
                <label className="text-xs font-bold uppercase text-slate-500">Gender</label>
                <div className="grid grid-cols-2 gap-2 mt-1">
                  {['male', 'female'].map((g) => (
                    <button key={g} onClick={() => setGender(g as any)} className={`py-2 rounded-xl text-sm font-bold ${gender === g ? 'bg-indigo-600 text-white' : 'bg-slate-100'}`}>
                      {g}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <Input label="Weight (kg)" type="number" value={weight} onChange={(e) => setWeight(Number(e.target.value))} />
            <Input label="Height (cm)" type="number" value={height} onChange={(e) => setHeight(Number(e.target.value))} />
            <Select label="Activity Level" options={ACTIVITY_OPTIONS} value={activityLevel} onChange={(e) => setActivityLevel(e.target.value as any)} />
            <Select label="Goal" options={GOAL_OPTIONS} value={goal} onChange={(e) => setGoal(e.target.value as any)} />
            <Button onClick={handleCalculate} fullWidth>Calculate Calories</Button>
          </div>
        </Card>

        <div className="space-y-4">
          {result && (
            <>
              <ResultCard label="Daily Calories" value={`${result.calories} kcal`} color="green" icon={<Utensils className="h-5 w-5" />} />
              <ResultCard label="BMR" value={`${result.bmr} kcal`} color="purple" icon={<Flame className="h-5 w-5" />} />
              <ResultCard label="TDEE" value={`${result.tdee} kcal`} color="blue" icon={<Target className="h-5 w-5" />} />
            </>
          )}
        </div>
      </div>
    </Container>
  );
}
