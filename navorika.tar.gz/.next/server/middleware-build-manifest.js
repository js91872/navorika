globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Cb-pbNBh0bswd5nBPTBdX/_buildManifest.js",
    "static/Cb-pbNBh0bswd5nBPTBdX/_ssgManifest.js",
    "static/Cb-pbNBh0bswd5nBPTBdX/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3mc6dra1m0098.js",
    "static/chunks/11jq0c2_zavac.js",
    "static/chunks/08ttfj81-47mu.js",
    "static/chunks/01l32msd8my4u.js",
    "static/chunks/turbopack-1wg7hph6sldpp.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
