module.exports=[88097,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_compress-jpg_page_actions_04ikpad.js.map