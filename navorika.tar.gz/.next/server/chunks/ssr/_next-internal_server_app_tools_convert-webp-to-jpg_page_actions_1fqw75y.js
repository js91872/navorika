module.exports=[32322,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_convert-webp-to-jpg_page_actions_1fqw75y.js.map