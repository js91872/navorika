module.exports=[42899,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_add-watermark_page_actions_197iaw7.js.map