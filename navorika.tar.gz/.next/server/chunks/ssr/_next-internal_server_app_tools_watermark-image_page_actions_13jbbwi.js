module.exports=[65832,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_watermark-image_page_actions_13jbbwi.js.map