module.exports=[26472,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_social-media-resizer_page_actions_0zqkbvr.js.map