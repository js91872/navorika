module.exports=[72065,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_pdf-metadata-editor_page_actions_1h8hps7.js.map