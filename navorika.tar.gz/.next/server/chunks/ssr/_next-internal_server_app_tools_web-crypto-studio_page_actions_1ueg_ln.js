module.exports=[10227,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_web-crypto-studio_page_actions_1ueg_ln.js.map