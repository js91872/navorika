module.exports=[88890,a=>{"use strict";var b=a.i(72131),c=a.i(50944);a.s(["default",0,function(){let a=(0,c.useRouter)();return(0,b.useEffect)(()=>{a.replace("/tools/cashflow-budget-architect/budget-planner")},[a]),null}])}];

//# sourceMappingURL=src_app_tools_cashflow-budget-architect_page_tsx_08fzz9s._.js.map