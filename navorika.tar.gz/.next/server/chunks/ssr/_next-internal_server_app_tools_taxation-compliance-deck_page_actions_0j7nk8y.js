module.exports=[86534,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_taxation-compliance-deck_page_actions_0j7nk8y.js.map