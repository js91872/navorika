module.exports=[8323,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_healthy-weight-calculator_page_actions_02w6bqj.js.map