module.exports=[28024,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_investment-return-profiler_page_actions_1buun7l.js.map