module.exports=[41834,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_lean-body-mass-calculator_page_actions_0n0irtf.js.map