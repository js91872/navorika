module.exports=[87274,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_calorie-calculator_page_actions_09qcn5l.js.map