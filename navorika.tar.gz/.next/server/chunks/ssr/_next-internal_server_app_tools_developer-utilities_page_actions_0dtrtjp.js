module.exports=[42073,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_developer-utilities_page_actions_0dtrtjp.js.map