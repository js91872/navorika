module.exports=[65148,a=>{"use strict";var b=a.i(72131),c=a.i(50944);a.s(["default",0,function(){let a=(0,c.useRouter)();return(0,b.useEffect)(()=>{a.replace("/tools/savings-retirement-hub/ppf-calculator")},[a]),null}])}];

//# sourceMappingURL=src_app_tools_savings-retirement-hub_page_tsx_027e-kd._.js.map