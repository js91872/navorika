module.exports=[26310,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_convert-jpg-to-webp_page_actions_1mrnbpu.js.map