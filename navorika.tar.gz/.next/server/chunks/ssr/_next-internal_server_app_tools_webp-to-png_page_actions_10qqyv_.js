module.exports=[98200,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_webp-to-png_page_actions_10qqyv_.js.map