module.exports=[45664,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_compress-png_page_actions_069f1l3.js.map