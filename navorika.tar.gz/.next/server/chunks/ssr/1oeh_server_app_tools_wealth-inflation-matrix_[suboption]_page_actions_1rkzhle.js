module.exports=[53224,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_tools_wealth-inflation-matrix_%5Bsuboption%5D_page_actions_1rkzhle.js.map