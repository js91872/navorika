module.exports=[34166,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_extract-pdf-pages_page_actions_1sfvdiv.js.map