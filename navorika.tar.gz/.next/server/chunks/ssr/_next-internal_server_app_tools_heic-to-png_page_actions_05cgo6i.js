module.exports=[92268,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_heic-to-png_page_actions_05cgo6i.js.map