module.exports=[86200,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_tdee-calculator_page_actions_1hvv5cg.js.map