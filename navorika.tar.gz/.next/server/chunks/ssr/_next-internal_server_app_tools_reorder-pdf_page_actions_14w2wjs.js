module.exports=[44042,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_reorder-pdf_page_actions_14w2wjs.js.map