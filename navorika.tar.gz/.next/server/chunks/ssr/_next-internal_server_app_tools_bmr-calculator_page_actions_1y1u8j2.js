module.exports=[35598,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_bmr-calculator_page_actions_1y1u8j2.js.map