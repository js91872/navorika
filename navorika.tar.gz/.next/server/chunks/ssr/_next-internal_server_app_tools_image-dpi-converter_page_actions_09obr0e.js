module.exports=[22773,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_image-dpi-converter_page_actions_09obr0e.js.map