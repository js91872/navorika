module.exports=[64659,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_rotate-image_page_actions_1c7l1e_.js.map