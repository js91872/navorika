module.exports=[50528,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_markup-formatter_page_actions_1ji5f00.js.map