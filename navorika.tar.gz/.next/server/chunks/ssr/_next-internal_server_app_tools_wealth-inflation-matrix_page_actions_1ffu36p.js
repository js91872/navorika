module.exports=[79262,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_wealth-inflation-matrix_page_actions_1ffu36p.js.map