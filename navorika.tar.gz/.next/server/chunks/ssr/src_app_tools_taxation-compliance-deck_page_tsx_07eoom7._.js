module.exports=[44604,a=>{"use strict";var b=a.i(72131),c=a.i(50944);a.s(["default",0,function(){let a=(0,c.useRouter)();return(0,b.useEffect)(()=>{a.replace("/tools/taxation-compliance-deck/income-tax-calculator")},[a]),null}])}];

//# sourceMappingURL=src_app_tools_taxation-compliance-deck_page_tsx_07eoom7._.js.map