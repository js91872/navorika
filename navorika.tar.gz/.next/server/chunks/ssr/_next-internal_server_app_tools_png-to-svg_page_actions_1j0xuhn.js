module.exports=[92601,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_png-to-svg_page_actions_1j0xuhn.js.map