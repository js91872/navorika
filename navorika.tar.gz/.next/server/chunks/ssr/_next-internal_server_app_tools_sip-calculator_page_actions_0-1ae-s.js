module.exports=[56138,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_sip-calculator_page_actions_0-1ae-s.js.map