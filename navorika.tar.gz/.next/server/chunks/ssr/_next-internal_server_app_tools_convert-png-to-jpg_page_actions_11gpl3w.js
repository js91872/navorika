module.exports=[31699,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_convert-png-to-jpg_page_actions_11gpl3w.js.map