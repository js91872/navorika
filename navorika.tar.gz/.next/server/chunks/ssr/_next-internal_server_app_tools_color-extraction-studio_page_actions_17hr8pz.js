module.exports=[36225,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_color-extraction-studio_page_actions_17hr8pz.js.map