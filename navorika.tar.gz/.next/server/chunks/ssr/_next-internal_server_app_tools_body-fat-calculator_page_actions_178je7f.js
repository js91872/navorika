module.exports=[44403,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_body-fat-calculator_page_actions_178je7f.js.map