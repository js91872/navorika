module.exports=[83267,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_tools_waist-to-height-ratio-calculator_page_actions_06jboxl.js.map