module.exports=[99942,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_bmi-calculator_page_actions_0-5v8mr.js.map