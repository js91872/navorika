module.exports=[90330,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_resize-image_page_actions_1gfof_w.js.map