module.exports=[72398,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_convert-jpg-to-png_page_actions_0bpofm7.js.map