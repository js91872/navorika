module.exports=[93942,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_add-page-numbers_page_actions_0fij019.js.map