module.exports=[48344,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_heic-to-jpg_page_actions_1vjbyue.js.map