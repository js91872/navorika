module.exports=[87880,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_crop-image_page_actions_0pgafa4.js.map