module.exports=[65945,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_compress-pdf_page_actions_03g38bd.js.map