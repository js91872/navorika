module.exports=[86840,a=>{"use strict";var b=a.i(72131),c=a.i(50944);a.s(["default",0,function(){let a=(0,c.useRouter)();return(0,b.useEffect)(()=>{a.replace("/tools/wealth-inflation-matrix/compound-interest-calculator")},[a]),null}])}];

//# sourceMappingURL=src_app_tools_wealth-inflation-matrix_page_tsx_1kmxf0_._.js.map