module.exports=[26822,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_brick-calculator_page_actions_1clahbu.js.map