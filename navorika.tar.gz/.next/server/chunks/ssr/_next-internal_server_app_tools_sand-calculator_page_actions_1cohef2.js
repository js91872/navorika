module.exports=[16747,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_sand-calculator_page_actions_1cohef2.js.map