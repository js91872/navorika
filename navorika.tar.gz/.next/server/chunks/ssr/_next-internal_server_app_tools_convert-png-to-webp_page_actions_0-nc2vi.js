module.exports=[98123,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_convert-png-to-webp_page_actions_0-nc2vi.js.map