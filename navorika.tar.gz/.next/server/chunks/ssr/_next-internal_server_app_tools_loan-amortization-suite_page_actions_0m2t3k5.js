module.exports=[56401,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_loan-amortization-suite_page_actions_0m2t3k5.js.map