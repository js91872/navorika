module.exports=[65576,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_calories-burned-calculator_page_actions_01nwi5d.js.map