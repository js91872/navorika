module.exports=[38401,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_ideal-weight-calculator_page_actions_0v29fbx.js.map