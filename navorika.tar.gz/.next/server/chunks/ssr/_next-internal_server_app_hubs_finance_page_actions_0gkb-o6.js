module.exports=[22770,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hubs_finance_page_actions_0gkb-o6.js.map