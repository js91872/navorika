module.exports=[84579,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_loan-emi-calculator_page_actions_13ornl4.js.map