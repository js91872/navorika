module.exports=[35891,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_running-calories-calculator_page_actions_0hovtbw.js.map