module.exports=[19943,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_concrete-calculator_page_actions_1tc3k81.js.map