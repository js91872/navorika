module.exports=[49066,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_image-to-pdf_page_actions_1_dlava.js.map