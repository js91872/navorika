module.exports=[44836,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_delete-pdf-pages_page_actions_15s3ihc.js.map