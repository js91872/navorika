module.exports=[26929,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_compress-image_page_actions_20_se8p.js.map