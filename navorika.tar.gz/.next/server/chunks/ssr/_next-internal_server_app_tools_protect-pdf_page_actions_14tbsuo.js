module.exports=[14910,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_protect-pdf_page_actions_14tbsuo.js.map