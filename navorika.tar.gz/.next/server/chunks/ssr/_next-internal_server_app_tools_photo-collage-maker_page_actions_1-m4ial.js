module.exports=[72276,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_photo-collage-maker_page_actions_1-m4ial.js.map