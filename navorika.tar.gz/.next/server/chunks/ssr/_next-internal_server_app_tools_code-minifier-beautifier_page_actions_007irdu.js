module.exports=[2663,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_code-minifier-beautifier_page_actions_007irdu.js.map