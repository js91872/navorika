module.exports=[74283,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_walking-calories-calculator_page_actions_04r2ag9.js.map