module.exports=[67673,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_sign-pdf_page_actions_0g26fqj.js.map