module.exports=[97198,a=>{"use strict";var b=a.i(72131),c=a.i(50944);a.s(["default",0,function(){let a=(0,c.useRouter)();return(0,b.useEffect)(()=>{a.replace("/tools/loan-amortization-suite/emi-calculator")},[a]),null}])}];

//# sourceMappingURL=src_app_tools_loan-amortization-suite_page_tsx_1t8_qx3._.js.map