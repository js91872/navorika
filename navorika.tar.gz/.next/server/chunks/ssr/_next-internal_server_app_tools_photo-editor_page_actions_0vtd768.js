module.exports=[9585,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_photo-editor_page_actions_0vtd768.js.map