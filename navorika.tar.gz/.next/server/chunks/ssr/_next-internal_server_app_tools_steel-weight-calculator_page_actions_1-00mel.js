module.exports=[75730,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_steel-weight-calculator_page_actions_1-00mel.js.map