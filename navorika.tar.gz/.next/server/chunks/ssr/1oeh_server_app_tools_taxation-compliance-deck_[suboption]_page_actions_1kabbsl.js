module.exports=[47893,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_tools_taxation-compliance-deck_%5Bsuboption%5D_page_actions_1kabbsl.js.map