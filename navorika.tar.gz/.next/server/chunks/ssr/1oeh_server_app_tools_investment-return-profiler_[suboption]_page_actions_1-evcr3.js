module.exports=[61738,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_tools_investment-return-profiler_%5Bsuboption%5D_page_actions_1-evcr3.js.map