module.exports=[29258,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_ppf-calculator_page_actions_115yxmr.js.map